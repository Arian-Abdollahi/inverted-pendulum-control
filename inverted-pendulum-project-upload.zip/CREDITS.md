# Credits and provenance

The submitted Persian project report attributes the course work to **Arian Abdollahi, Matin Masoudi, Armin Hatami, and Mohammad Sadegh Rezvani**. The supplied materials do not specify individual contributions. The report credits the instructor **Dr. Iman Sharifi** and teaching assistant **Sina Rabiei**.

The following bundled materials are separate from the student project's original MATLAB scripts:

- `third_party/inverted-pendulum-simulink/`: an example by **Jitendra Singh**, which includes an **MIT license (2021)**. Its original README and license are preserved.
- `third_party/legacy-gui/`: historical inverted-pendulum animation GUI code whose comments identify **Copyright (C) 1997, Regents of the University of Michigan**. The supplied archive provides no separate license for that GUI; treat its redistribution terms as needing review before public release.
- `media/`: supplied illustrative animations and video whose original creators/licenses are not established by the files. Do not claim they are original team work.
- `references/assignment_brief.pdf`: the provided university course assignment (not the team's authored report).

**No repository-wide license is assigned here.** Do not imply that these third-party components are relicensed by the student project.
