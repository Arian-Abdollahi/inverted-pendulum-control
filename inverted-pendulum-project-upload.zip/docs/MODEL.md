# Inverted pendulum on a cart: model

Source: the supplied Persian report (`reports/project_report.pdf`) and MATLAB scripts under `analysis/modeling/`.

The linearized upright model uses state vector `x = [cart position, cart velocity, pendulum angle, angular velocity]^T` with force input `u` and output `[cart position, pendulum angle]`.

Nominal parameters in the team's `state.m`:

| Symbol | Description | Value |
|---|---|---:|
| M | Cart mass (kg) | 0.5 |
| m | Pendulum mass (kg) | 0.2 |
| b | Cart viscous friction | 0.1 |
| I | Pendulum inertia | 0.006 |
| g | Gravitational acceleration (m/s²) | 9.8 |
| l | Pendulum center-of-mass distance (m) | 0.3 |

Let `p = I*(M+m) + M*m*l^2` (equal to `(M+m)*(I+m*l^2)-(m*l)^2`). The scripts set:

```
A = [0,                 1,                   0,              0;
     0, -(I+m*l^2)*b/p,        m^2*g*l^2/p,              0;
     0,                 0,                   0,              1;
     0,          -m*l*b/p,       m*g*l*(M+m)/p,            0]
B = [0; (I+m*l^2)/p; 0; m*l/p]
C = [1 0 0 0; 0 0 1 0], D = [0; 0]
```

`analysis/modeling/transfer_function.m` derives cart and pendulum transfer functions. The upright equilibrium is unstable without control. Read the submitted report for the original derivation and analyses.
