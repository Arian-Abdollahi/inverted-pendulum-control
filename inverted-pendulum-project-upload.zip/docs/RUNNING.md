# Running the original MATLAB/Simulink project

## Requirements

- MATLAB + Control System Toolbox for `tf`, `ss`, `rlocus`, `pid`, `acker`, and `stepinfo`.
- Simulink for `.slx` models.
- The optional third-party 3D animation may require Simulink 3D Animation and legacy VR Sink support.
- Exact original MATLAB version is unknown; compatibility has not been verified.

Clone/open the repository and run **one script at a time from the project root**. Some scripts define variables in the base workspace; do not run the whole tree as a single pipeline.

```matlab
run('analysis/modeling/state.m');
eigenvalues
run('analysis/modeling/transfer_function.m');

clearvars;
run('controllers/pid/final_pid.m');

clearvars;
run('controllers/state_feedback/state_feedback.m');

open_system('controllers/pid/PID.slx');
open_system('controllers/nonlinear/nonlinearfinal.slx');
```

Do not use `addpath(genpath(pwd))`; legacy scripts have names that may shadow MATLAB built-ins and third-party dependencies. Some saved Simulink models depend on base-workspace variables, so inspect model initialization before simulating. Start the 3D example from `third_party/inverted-pendulum-simulink/Init_Setup_LQRArd.m` using its original README.

## Original script limitations

- `controllers/pid/paydari_bad_pid.m` refers to **`g1`**, although its initialization is commented out. It will fail in a clean workspace without adjustment.
- Several scripts use fixed plotting limits and controller values, which should not be treated as a common tuned configuration.
- The scripts in `analysis/` and `controllers/` are preserved from the supplied archive, apart from organizing paths/renaming `step.m`, `nyquist.m`, and `bode.m` to avoid shadowing MATLAB built-ins.

Saved figures are evidence of the submitted runs; MATLAB/Simulink simulations have not been rerun for this imported package.
