# Inverted Pendulum Control

MATLAB and Simulink project studying a cart-mounted inverted pendulum: linearization, stability, PID control, full-state feedback, and nonlinear comparisons.

The original work is documented in a **34-page Persian report**, and a separate **17-page course assignment** is preserved for context. Original scripts are kept as provided, organized into Git-friendly folders without claiming that they have been rerun.

## Repository map

| Folder | Contents |
| --- | --- |
| [`analysis/`](analysis/) | State-space and transfer-function modeling, model-order comparison, root locus, step, Bode, Nyquist |
| [`controllers/pid/`](controllers/pid/) | PID scripts, Simulink model, saved output figures |
| [`controllers/state_feedback/`](controllers/state_feedback/) | State-feedback/Ackermann pole-placement scripts and Simulink models |
| [`controllers/nonlinear/`](controllers/nonlinear/) | Nonlinear Simulink model and saved comparison plots |
| [`figures/`](figures/) | Submitted modeling and open-loop figures |
| [`reports/`](reports/) | Original submitted report (PDF and DOCX) |
| [`references/`](references/) | University course assignment brief (PDF) |
| [`media/`](media/) | Supplied animation GIFs and video; provenance not established |
| [`third_party/`](third_party/) | Separately credited external Simulink example and legacy GUI |
| [`docs/`](docs/) | Model summary, running guide, results, verification |

## Selected submitted results

| PID step response | State-feedback step response |
| --- | --- |
| ![PID step response](controllers/pid/final-pid-step.png) | ![State-feedback response](controllers/state_feedback/state_feedback_step_response.png) |

These are **saved figures from the submitted project**, not newly generated benchmarks. Different scripts use different gains, and the supplied nonlinear results do not demonstrate robust stabilization across all operating conditions.

## Quick start

Requires MATLAB + Control System Toolbox, and Simulink for `.slx` models. Open MATLAB at the repository root:

```matlab
run('analysis/modeling/state.m');
eigenvalues
run('analysis/modeling/transfer_function.m');

clearvars;
run('controllers/pid/final_pid.m');

clearvars;
run('controllers/state_feedback/state_feedback.m');

open_system('controllers/pid/PID.slx');
```

See [running instructions](docs/RUNNING.md) before launching the models. **Do not recursively add all directories to MATLAB's path.** Some scripts rely on workspace state or require manual inspection.

## Validation

Static repository/Simulink archive integrity (does not run MATLAB):

```bash
python scripts/validate_structure.py
```

The report and project scripts are preserved; MATLAB simulations were **not rerun**. See [verification limits](docs/VERIFICATION.md).

## Credits and reuse

Submitted report: Arian Abdollahi, Matin Masoudi, Armin Hatami, Mohammad Sadegh Rezvani. Third-party examples and unclear-provenance media are separately identified in [CREDITS.md](CREDITS.md); do not assume the MIT license on one third-party example covers the entire repository. No repository-wide license has been assigned.
